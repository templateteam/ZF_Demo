使用方法：
cordova  plugin add  《插件路径》 com.pay.ICBCPayPlugin
例如：
cordova plugin add /Users/apple/Project/pi_工行/ZF_Demo/ICBCPayPlugin
