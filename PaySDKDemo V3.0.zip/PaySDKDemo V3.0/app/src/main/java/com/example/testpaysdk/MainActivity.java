package com.example.testpaysdk;

import java.util.ArrayList;

import com.icbc.paysdk.ICBCAPI;
import com.icbc.paysdk.constants.Constants;
import com.icbc.paysdk.model.PayReq;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
	
	ICBCAPI api;
	EditText edit_interfaceName ;
	EditText edit_interfaceVersion;
	EditText edit_tranData;
	EditText edit_MerSignMsg;
	EditText edit_MerCert;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
				
		Button pay_btn = (Button) findViewById(R.id.pay_btn);
		pay_btn.setOnClickListener(pay_btn_ClickListener);
		
		edit_interfaceName = (EditText)findViewById(R.id.edit_interfaceName);
		edit_interfaceVersion = (EditText)findViewById(R.id.edit_interfaceVersion);
		edit_tranData = (EditText)findViewById(R.id.edit_tranData);
		edit_MerSignMsg = (EditText)findViewById(R.id.edit_MerSignMsg);
		edit_MerCert = (EditText)findViewById(R.id.edit_MerCert);
		
		AddressDialog2().show();
									
	}
	
	
	private OnClickListener pay_btn_ClickListener = new View.OnClickListener()
    {

		@Override
		public void onClick(View arg0) {
			// TODO 自动生成的方法存根
			
			Log.i("pay","pay_btn");
			
			String interfaceName = "ICBC_WAPB_B2C";
			String interfaceVersion = "1.0.0.6";
			String tranData = "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iR0JLIiBzdGFuZGFsb25lPSJubyI/PjxCMkNSZXE+PGludGVyZmFjZU5hbWU+SUNCQ19XQVBCX0IyQzwvaW50ZXJmYWNlTmFtZT48aW50ZXJmYWNlVmVyc2lvbj4xLjAuMC42PC9pbnRlcmZhY2VWZXJzaW9uPjxvcmRlckluZm8+PG9yZGVyRGF0ZT4yMDE5MDEyMTE2MjAxNDwvb3JkZXJEYXRlPjxvcmRlcmlkPjIwMTkwMTIxMTYyMDE0MDwvb3JkZXJpZD48YW1vdW50PjE2MjA8L2Ftb3VudD48aW5zdGFsbG1lbnRUaW1lcz4xPC9pbnN0YWxsbWVudFRpbWVzPjxjdXJUeXBlPjAwMTwvY3VyVHlwZT48bWVySUQ+MDIwMEVDMjMzMzUxNDk8L21lcklEPjxtZXJBY2N0PjAyMDAwMjQxMDkwMzE1NDg1Njk8L21lckFjY3Q+PC9vcmRlckluZm8+PGN1c3RvbT48dmVyaWZ5Sm9pbkZsYWc+MDwvdmVyaWZ5Sm9pbkZsYWc+PExhbmd1YWdlPnpoX0NOPC9MYW5ndWFnZT48L2N1c3RvbT48bWVzc2FnZT48Z29vZHNJRD4wMDE8L2dvb2RzSUQ+PGdvb2RzTmFtZT6z5Na1v6g8L2dvb2RzTmFtZT48Z29vZHNOdW0+MjwvZ29vZHNOdW0+PGNhcnJpYWdlQW10PjEwMDA8L2NhcnJpYWdlQW10PjxtZXJIaW50PrjDyczGt7K7u7uyu83LPC9tZXJIaW50PjxyZW1hcmsxPjwvcmVtYXJrMT48cmVtYXJrMj48L3JlbWFyazI+PG1lclVSTD5odHRwOi8vMTIyLjE5LjE0MS44My9lbXVsYXRvci9XYXBfc2hvcF9yZXN1bHQxLmpzcDwvbWVyVVJMPjxtZXJWQVI+PC9tZXJWQVI+PG5vdGlmeVR5cGU+SFM8L25vdGlmeVR5cGU+PHJlc3VsdFR5cGU+MTwvcmVzdWx0VHlwZT48YmFja3VwMT48L2JhY2t1cDE+PGJhY2t1cDI+PC9iYWNrdXAyPjxiYWNrdXAzPjwvYmFja3VwMz48YmFja3VwND48L2JhY2t1cDQ+PC9tZXNzYWdlPjwvQjJDUmVxPg==";
			String merSignMsg = "X7WAtQIxCZlR+wnbG+b6ZYIyjkha5xK1QiaCb+RNYxH33CQWRy9CDZDtBLGwi9rbYJnNKnsR6JvFj+jO5BJDNp8qEd3b4KsYfzZWdvgHh1epkLzCVnfFV2sQi4eXMQC/dcgWXTWDwZAoXhMQhUs1KEt7da71RV4vWOEPyEoJfUg=";
			String merCert = "MIIChjCCAe+gAwIBAgIKbaHKEE0tAAAH3zANBgkqhkiG9w0BAQUFADA2MRkwFwYDVQQDExBjb3JiYW5rNDMgc2RjIENOMRkwFwYDVQQKExBjb3JiYW5rNDMuY29tLmNuMB4XDTE1MTEzMDAyMzczMloXDTE2MTEzMDAyMzczMlowPzETMBEGA1UEAxMKQjJDLmUuMDIwMDENMAsGA1UECxMEMDIwMDEZMBcGA1UEChMQY29yYmFuazQzLmNvbS5jbjCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAwV4bOl8ByDx1So1smhCWvzCegIVze5T6qreQyUiBYI6B5hnkd6ke3ToxFUDRawdN8JWAGW+0Ze02irfg4cnZs3f8PHZ5IEiLYOGrHUWfEsk3QhKrSCLyyzIACeceNMVlIcjzYtemziNej5NZsv787WQSpY5gy+2vNUDt+f/Hj6ECAwEAAaOBkTCBjjAfBgNVHSMEGDAWgBS+7/FOAOQ4De97QGDOvMygCG34YzBMBgNVHR8ERTBDMEGgP6A9pDswOTENMAsGA1UEAxMEY3JsMzENMAsGA1UECxMEY2NybDEZMBcGA1UEChMQY29yYmFuazQzLmNvbS5jbjAdBgNVHQ4EFgQUfTKD6Q/uHEN8zthhoVr3/KCJiQcwDQYJKoZIhvcNAQEFBQADgYEALHBcTTjXI5fgd/b60y8ObhxMGWiDDpb2f9gMoKYmkGhFCf2+KGSBpPuYc9u3J8P0CUQ9znyYpxSGXKzVHh34PYxvGLpCQZ/liSKsfgD/JXvNqwgBmMXq0MzoMrYc6JMaMvSmfy/jVq9D6YFM5AnzsKLG+FQPckNx6O7pRqNzL1E=";

			
			PayReq req = new PayReq();
			req.setInterfaceName(interfaceName);
			req.setInterfaceVersion(interfaceVersion);
			req.setTranData(tranData);
			req.setMerSignMsg(merSignMsg);
			req.setMerCert(merCert);
			ICBCAPI.getInstance().sendReq(MainActivity.this,req);
			
			
		}

    };
    
		private String testServerURL = "";
		private String[] arrs = null;
	    
		private AlertDialog AddressDialog2() {
					
			arrs = getResources().getStringArray(R.array.TestServerIP);
	
			final ArrayList<String> arrsDisplay = new ArrayList<String>();
			for (String s : arrs) {
					arrsDisplay.add(s);

			}
			Builder dialog = new AlertDialog.Builder(MainActivity.this);
//			dialog.setIcon(R.drawable.small_icon);
			dialog.setTitle("测试环境地址");
			dialog.setSingleChoiceItems(arrsDisplay.toArray(new String[arrsDisplay.size()]), 0, new android.content.DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					if (which == 0)
						testServerURL = "";
					else
						testServerURL = arrs[which];
				}
			});
			dialog.setPositiveButton("确定", new android.content.DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					if ("".equals(testServerURL)) {
						AddressDialog1().show();
					} else {
						String[] temp = testServerURL.split("\\|");
						Constants.PAY_LIST_IP = temp[0].trim();
					//	Constants.Start_B2C_IP = temp[1].trim();
					}
					arg0.dismiss();
				}
			});
			return dialog.create();
		}
	
		private AlertDialog AddressDialog1() {
			Builder MessageDialog = null;
			MessageDialog = new Builder(MainActivity.this);
			LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			LinearLayout view = (LinearLayout) layoutInflater.inflate(R.layout.dialog_edittext, null);
			final EditText input1 = (EditText) view.findViewById(R.id.edittext1);
		//	final EditText input2 = (EditText) view.findViewById(R.id.edittext2);
			input1.setText("http://");
		//	input2.setText("http://");
			MessageDialog.setView(view);
			MessageDialog.setTitle("测试环境地址");
			MessageDialog.setPositiveButton("确定", new android.content.DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					String value1 = input1.getText().toString();
				//	String value2 = input2.getText().toString();
					Constants.PAY_LIST_IP = value1.trim();
				//	Constants.Start_B2C_IP = value2.trim();
					arg0.dismiss();
				}
			});
			return MessageDialog.create();
		}
	     	
}
